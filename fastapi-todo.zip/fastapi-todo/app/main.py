
from fastapi import FastAPI
from .database import Base, engine
from .routers import auth, tasks

app = FastAPI(title="ToDo API", version="1.0.0")

# Create tables on startup (simple approach; for production prefer Alembic migrations)
@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(tasks.router, prefix="/tasks", tags=["tasks"])

@app.get("/", tags=["health"])
def health():
    return {"status": "ok"}
