
from __future__ import annotations
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict
from .models import TaskStatus

# User
class UserBase(BaseModel):
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: Optional[str] = None
    username: str = Field(..., min_length=3, max_length=150)

class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=128)

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    first_name: str
    last_name: Optional[str] = None
    username: str

# Token
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

# Task
class TaskBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    status: TaskStatus = TaskStatus.NEW

class TaskCreate(TaskBase):
    pass

class TaskUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    status: Optional[TaskStatus] = None

class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: Optional[str] = None
    status: TaskStatus
    user_id: int

class PaginatedTasks(BaseModel):
    total: int
    limit: int
    offset: int
    items: List[TaskOut]
