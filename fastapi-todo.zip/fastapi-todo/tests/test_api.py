
import os
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
os.environ["JWT_SECRET"] = "testsecret"

from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine

# Fresh DB for tests
Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

client = TestClient(app)

def register_and_login(username="alice", password="secret123", first_name="Alice"):
    r = client.post("/auth/register", json={
        "first_name": first_name,
        "last_name": "Tester",
        "username": username,
        "password": password
    })
    assert r.status_code == 201 or r.status_code == 400  # allow re-run
    r = client.post("/auth/login", data={"username": username, "password": password})
    assert r.status_code == 200
    token = r.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}

def test_task_crud_flow():
    headers = register_and_login()

    # Create
    r = client.post("/tasks", json={"title": "Buy milk", "description": "2 liters"}, headers=headers)
    assert r.status_code == 201, r.text
    task_id = r.json()["id"]

    # Read my list
    r = client.get("/tasks", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert data["total"] >= 1
    assert any(item["id"] == task_id for item in data["items"])

    # Get specific
    r = client.get(f"/tasks/{task_id}", headers=headers)
    assert r.status_code == 200
    assert r.json()["title"] == "Buy milk"

    # Update
    r = client.put(f"/tasks/{task_id}", json={"status": "In Progress"}, headers=headers)
    assert r.status_code == 200
    assert r.json()["status"] == "In Progress"

    # Mark completed
    r = client.post(f"/tasks/{task_id}/complete", headers=headers)
    assert r.status_code == 200
    assert r.json()["status"] == "Completed"

    # Filter by status
    r = client.get("/tasks", params={"status": "Completed"}, headers=headers)
    assert r.status_code == 200
    assert all(item["status"] == "Completed" for item in r.json()["items"])

    # Delete
    r = client.delete(f"/tasks/{task_id}", headers=headers)
    assert r.status_code == 204

    # Verify deletion
    r = client.get(f"/tasks/{task_id}", headers=headers)
    assert r.status_code == 403 or r.status_code == 404
